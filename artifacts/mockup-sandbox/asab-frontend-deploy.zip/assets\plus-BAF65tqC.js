import{c as e}from"./index-BP1H1G6-.js";const o=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],c=e("plus",o);export{c as P};
